from .ooh import OOH

dataset_list = {"ooh": OOH}

def build_dataset(dataset, root_path, shots):
    return dataset_list[dataset](root_path, shots)